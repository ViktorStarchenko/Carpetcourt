<?php
/*
Plugin Name: CSV Product Import Table
Plugin URI:
Version: 0.1
Author: CodePixelzMedia
*/

class csv_import_table {

	function __construct() {

		add_action( 'admin_menu', array( $this , 'register_admin_menu_csv' ) );
		add_action( 'admin_enqueue_scripts', array( $this , 'csv_import_table_script' ) );
		add_action( 'wp_ajax_upload_product_csv' , array( $this , 'upload_csv' ) );
		add_action( 'wp_ajax_upload_color_csv' , array( $this , 'upload_color_csv' ) );
	}

	function printr( $value ){
		echo '<pre>'; print_r( $value ); echo '</pre>';

	}

	// Uploads CSV to the directory
	function upload_to_directory( $files ){

		$files_temp = file_get_contents( $files["file"]["tmp_name"][0]);
		$upload = wp_upload_bits( $files["file"]["name"][0], null, $files_temp);

		$link = $upload['url'];

		$upload_dir = wp_upload_dir();
		$image_data = file_get_contents($link);
		$filename = basename($link);
		if (wp_mkdir_p($upload_dir['basedir']))
			$file = $upload_dir['path'] . '/' . $filename;
		else
			$file = $upload_dir['path'] . '/' . $filename;

		return $file;

	}


	//upload color to the table
	function upload_color_csv() {

		global $wpdb;
		$table_name = $wpdb->prefix . 'post_meta';
		$table_post = $wpdb->prefix . 'posts';

		$csv = $this->upload_to_directory( $_FILES );
		$file = fopen($csv, "r");

		if ( $file !== false) {
			$i=0;
			while (($value = fgetcsv($file, 1000, ',')) !== false ) {

				if ($i > 0) {

					if ( !empty( $value[2] ) ) {

						//cpm_insert_terms($term, $taxonomy, $slug);



						$color_array = $this->cpm_insert_terms( $value[2], 'pa_color', $value[3]);
						if ( !empty( $color_array) && !empty( $value[5] ) ) {
							cc_update_term_meta_data( $color_array['term_id'], 'cpm_color_thumbnail', $value[5]);
						}
						if ( !empty( $value[4] ) ) {
							$this->cpm_relate_terms_colors( $value[4], 'pa_filter-colour', $color_array );
						}
						if ( !empty( $value[7] ) ) {
							$this->cpm_relate_terms_colors( $value[7], 'pa_rent', $color_array );
						}
						if ( !empty( $value[8] ) ) {
							$this->cpm_relate_terms_colors( $value[8], 'pa_sell', $color_array );
						}

						if ( !empty( $value[9] ) ) {
							$this->cpm_relate_terms_colors( $value[9], 'pa_floor', $color_array );
						}
						if ( !empty( $value[10] ) ) {
							$this->cpm_relate_terms_colors( $value[10], 'pa_style', $color_array );
						}
						if ( !empty( $value[11] ) ) {
							$this->cpm_relate_terms_colors( $value[11], 'product_color', $color_array );
						}
						if ( !empty( $value[12] ) ) {
							$this->cpm_relate_terms_colors( $value[12], 'product_accent', $color_array );
						}
					}
				}
				$i++;
				unset( $value );
			}
		}


		die();

	}

	// Upload and insert to the table
	function upload_csv(){
		global $wpdb;
		$table_name = $wpdb->prefix . 'post_meta';
		$table_post = $wpdb->prefix . 'posts';

		$csv = $this->upload_to_directory( $_FILES );
		$file = fopen($csv, "r");
		$i = 0;
		$post_desc = array();
		$post_title = array();
		$part_num = array();
		$insert_data = array();

		if ( $file !== false) {
			$i=0;
			while (($value = fgetcsv($file, 1000, ',')) !== false ) {

				if ($i > 0) {
					if ( !empty( $value[3] ) ) {
						$post_title = $value[3];
						$description = $value[16];
						$comment_status = '';
						if ( $value[82] != 0 ) {
							$comment_status = 'closed';
						} else {
							$comment_status = 'open';
						}
						$post_back_end = get_page_by_title( $post_title, 'OBJECT','product' );
						if (!$post_back_end) {
							$my_post = array(
								'post_type'     => 'product',
								'post_title'    => $post_title,
								'post_content'  => $description,
								'post_status'   => 'publish',
								'post_author'   => 1,
								// 'comment_status' => $comment_status

								);
							$post_ids = wp_insert_post( $my_post );

						/*update_post_meta( $post_ids, 'post_indent', $value[38] );
						$this->set_post_terms( $post_ids, $value[32], 'product_tag' );
						$this->set_post_terms( $post_ids, $value[33], 'product_brand' );
						$this->set_post_terms( $post_ids, $value[35], 'product_cat' );
						$this->set_post_terms( $post_ids, $value[36], 'pa_material' );
						$this->set_post_terms( $post_ids, $value[37], 'pa_fibre' );
						$this->set_post_terms( $post_ids, $value[44], 'pa_color' );
						$this->set_post_terms( $post_ids, $value[51], 'pa_rent' );
						$this->set_post_terms( $post_ids, $value[52], 'pa_sell' );
						$this->set_post_terms( $post_ids, $value[52], 'pa_floor' );
						$this->set_post_terms( $post_ids, $value[53], 'pa_style' );
						$this->set_post_terms( $post_ids, $value[54], 'product_color' );
						$this->set_post_terms( $post_ids, $value[56], 'product_delivery' );
						$this->set_post_terms( $post_ids, $value[83], 'pa_looks' );
						$this->set_post_attr_features_terms( $post_ids, $value[57], 'Affordable' );
						$this->set_post_attr_features_terms( $post_ids, $value[58], 'Luxury' );
						$this->set_post_attr_features_terms( $post_ids, $value[59], 'Durable' );
						$this->set_post_attr_features_terms( $post_ids, $value[60], 'Scratch + Dent' );
						$this->set_post_attr_features_terms( $post_ids, $value[61], 'Pet Friendly' );
						$this->set_post_attr_features_terms( $post_ids, $value[62], 'Kid Friendly' );
						$this->set_post_attr_features_terms( $post_ids, $value[63], 'Easy Maintenance' );
						$this->set_post_attr_features_terms( $post_ids, $value[64], 'Allergy Friendly' );
						$this->set_post_attr_features_terms( $post_ids, $value[65], 'Heavy Wear' );
						$this->set_post_attr_features_terms( $post_ids, $value[66], 'Water Resistant' );
						$this->set_post_attr_features_terms( $post_ids, $value[67], 'Stain Resistant' );
						$this->set_post_attr_features_terms( $post_ids, $value[86], 'Fade Resistant' );
						$this->set_post_attr_features_terms( $post_ids, $value[69], 'Exclusive' );
						$this->set_post_attr_features_terms( $post_ids, $value[70], 'Quiet Choice' );
						$this->set_post_attr_features_terms( $post_ids, $value[71], 'Eco-Friendly' );
						$this->set_post_attr_features_terms( $post_ids, $value[72], 'Luxury' );
						$this->set_post_attr_features_terms( $post_ids, $value[73], 'Natural Material' );
						$this->set_post_attr_features_terms( $post_ids, $value[74], 'Underfloor Heating Compatible' );
						$this->set_post_attr_features_terms( $post_ids, $value[75], 'Kitchens' );
						$this->set_post_attr_features_terms( $post_ids, $value[76], 'Bathrooms' );
						$this->set_post_attr_features_terms( $post_ids, $value[77], 'Living' );
						$this->set_post_attr_features_terms( $post_ids, $value[78], 'Bedrooms' );
						$this->set_post_attr_features_terms( $post_ids, $value[79], 'Outdoor' );*/
						// update_field( 'indent', $value[38], $post_ids );
						update_field( 'best_for', $value[9], $post_ids );
						update_field( 'avoid_if', $value[10], $post_ids );
						update_field( 'suits_styles', $value[12], $post_ids );
						update_field( 'suits_lifestyle', $value[11], $post_ids );
						update_field( 'lifespan', $value[13], $post_ids );


					} else {
						/*update_post_meta( $post_back_end->ID, 'post_indent', $value[38] );
						$this->set_post_terms( $post_back_end->ID, $value[32], 'product_tag' );
						$this->set_post_terms( $post_back_end->ID, $value[33], 'product_brand' );
						$this->set_post_terms( $post_back_end->ID, $value[35], 'product_cat' );
						$this->set_post_terms( $post_back_end->ID, $value[36], 'pa_material' );
						$this->set_post_terms( $post_back_end->ID, $value[37], 'pa_fibre' );
						$this->set_post_terms( $post_back_end->ID, $value[44], 'pa_color' );
						$this->set_post_terms( $post_back_end->ID, $value[51], 'pa_rent' );
						$this->set_post_terms( $post_back_end->ID, $value[52], 'pa_sell' );
						$this->set_post_terms( $post_back_end->ID, $value[52], 'pa_floor' );
						$this->set_post_terms( $post_back_end->ID, $value[53], 'pa_style' );
						$this->set_post_terms( $post_back_end->ID, $value[54], 'product_color' );
						$this->set_post_terms( $post_back_end->ID, $value[56], 'product_delivery' );
						$this->set_post_terms( $post_back_end->ID, $value[83], 'pa_looks' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[57], 'Affordable' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[58], 'Luxury' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[59], 'Durable' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[60], 'Scratch + Dent' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[61], 'Pet Friendly' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[62], 'Kid Friendly' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[63], 'Easy Maintenance' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[64], 'Allergy Friendly' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[65], 'Heavy Wear' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[66], 'Water Resistant' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[67], 'Stain Resistant' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[86], 'Fade Resistant' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[69], 'Exclusive' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[70], 'Quiet Choice' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[71], 'Eco-Friendly' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[72], 'Luxury' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[73], 'Natural Material' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[74], 'Underfloor Heating Compatible' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[75], 'Kitchens' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[76], 'Bathrooms' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[77], 'Living' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[78], 'Bedrooms' );
						$this->set_post_attr_features_terms( $post_back_end->ID, $value[79], 'Outdoor' );
						update_field( 'indent', $value[38], $post_back_end->ID );*/
						update_field( 'best_for', $value[9], $post_back_end->ID );
						update_field( 'avoid_if', $value[10], $post_back_end->ID );
						update_field( 'suits_styles', $value[12], $post_back_end->ID );
						update_field( 'suits_lifestyle', $value[11], $post_back_end->ID );
						update_field( 'lifespan', $value[13], $post_back_end->ID );
					}
				}
			}
			$i++;
			unset( $value );
		}
	}


	die();
}


	//color csv insert term
function cpm_insert_terms( $term, $taxonomy, $slug ) {

		$term_exists = term_exists( $term, $taxonomy ); // array is returned if taxonomy is given
		// $parent_term_id = $parent_term['term_id']; // get numeric term id
		if ($term_exists !== 0 && $term_exists !== null) {
			return $term_exists;
		} else {

			$insert_terms = wp_insert_term(
			  $term, // the term
			  $taxonomy, // the taxonomy
			  array(
			  	'description'=> '',
			  	'slug' => sanitize_title( $slug ),
			  	'parent'=> ''
			  	)
			  );

			return $insert_terms;
		}

	}

	//relate colors with other terms
	function cpm_relate_terms_colors( $term, $taxonomy, $color_array ) {

		$tags = explode( ',', trim( $term, " \n\t\r\0\x0B," ) );
		$trim_terms = array_filter(array_map('trim', $tags ) );

		foreach ($trim_terms as $trim_value) {

			if ( $taxonomy == 'product_accent' ) {
				$taxonomy = 'product_color';
			}

			$term_exists = term_exists( $trim_value, $taxonomy ); // array is returned if taxonomy is given
			// get numeric term id
			if ($term_exists !== 0 && $term_exists !== null) {

				$this->set_term_color_relation( $term_exists, $color_array, $taxonomy );

			} else {

				$insert_terms = wp_insert_term(
				  $trim_value, // the term
				  $taxonomy, // the taxonomy
				  array(
				  	'description'=> '',
				  	'slug' => '',
				  	'parent'=> ''
				  	)
				  );
				$this->set_term_color_relation( $insert_terms, $color_array, $taxonomy );

			}
		}


	}

	//set term and color relation
	function set_term_color_relation( $term_array, $color_array, $taxonomy ) {

		if ( $taxonomy == 'product_accent' ) {
			$taxonomy = 'product_color';
		}

		$related_terms = cc_get_term_meta( $term_array['term_id'], 'related_'.$taxonomy, true );
		if ( empty( $related_terms ) ) {
			$related_terms = array();
		}

		if ( !in_array( $color_array['term_id'], $related_terms ) ) {
			array_push( $related_terms, $color_array['term_id'] );
		}
		if ( !empty( $related_terms ) ) {
			cc_update_term_meta_data( $term_array['term_id'], 'related_'.$taxonomy, $related_terms);
		}

	}

	function set_post_terms( $post_id, $term, $taxonomy ) {


		if ( !empty( $term ) ) {

			$tags = explode( ',', trim( $term, " \n\t\r\0\x0B," ) );
			$trim_terms = array_filter(array_map('trim', $tags ) );
			if ( $taxonomy == 'product_tag') {
				wp_set_object_terms( $post_id, $trim_terms, $taxonomy, true );
			} else {


				foreach ($trim_terms as $tags_value) {
					$term_exists = term_exists( $tags_value, $taxonomy );

					if ( $term_exists === null) {
						$insert_terms = wp_insert_term($tags_value, $taxonomy );

						$term_gets = get_term_by( 'id', $insert_terms['term_id'] );

						wp_set_object_terms( $post_id, array( $insert_terms['term_id'] ), $taxonomy, true );
					} else {

						$term_getsd = get_term_by( 'id', $term_exists['term_id'] );

						wp_set_post_terms( $post_id, array($term_exists['term_id']), $taxonomy, true );
					}
				}

			}

			$product_attributes = get_post_meta( $post_id, '_product_attributes', true );
			$attributes = wc_get_attribute_taxonomy_names();

			$prod_attributes = array();



			if ( in_array( $taxonomy, $attributes ) ) {

				if ( !empty( $product_attributes ) ) {

					$key_position = count( $product_attributes );
					$position = 0;

					$prod_attributes = $product_attributes;

					if ( !array_key_exists( $taxonomy, $prod_attributes ) ) {

						$prod_attributes[$taxonomy] = array(
							'name' => $taxonomy,
							'value' => '',
							'position' => $position,
							'is_visible' => 1,
							'is_variation' => 0,
							'is_taxonomy' => 1,
							);

						update_post_meta( $post_id, '_product_attributes', $prod_attributes );
					} else {
						$prod_attributes[$taxonomy]['name'] = $taxonomy;
						$prod_attributes[$taxonomy]['value'] = '';
						$prod_attributes[$taxonomy]['position'] = $position;
						$prod_attributes[$taxonomy]['is_visible'] = 1;
						$prod_attributes[$taxonomy]['is_variation'] = 0;
						$prod_attributes[$taxonomy]['is_taxonomy'] = 1;

						update_post_meta( $post_id, '_product_attributes', $prod_attributes );
					}

				} else {
					$prod_attributes[$taxonomy] = array(
						'name' => $taxonomy,
						'value' => '',
						'position' => 0,
						'is_visible' => 1,
						'is_variation' => 0,
						'is_taxonomy' => 1,
						);
					update_post_meta( $post_id, '_product_attributes', $prod_attributes );
				}

			}
		}

	}

	function set_post_attr_features_terms( $post_id, $value, $term_name ) {

		$product_feature_term_exists = term_exists($term_name, 'product_feature');
		$additional_option_term_exists = term_exists($term_name, 'additional_option');

		if ( is_numeric( $value ) && !empty( $value ) && $value == 1 ) {

			if ( $product_feature_term_exists === null) {
				$product_feature_insert_terms = wp_insert_term($term_name, 'product_feature' );

				wp_set_object_terms( $post_id, array( $product_feature_insert_terms['term_id'] ), 'product_feature', true );
			} else {

				wp_set_post_terms( $post_id, array($product_feature_term_exists['term_id']), 'product_feature', true );
			}

			if ( $additional_option_term_exists === null) {
				$additional_option_insert_terms = wp_insert_term($term_name, 'additional_option' );

				wp_set_object_terms( $post_id, array( $additional_option_insert_terms['term_id'] ), 'additional_option', true );
			} else {

				wp_set_post_terms( $post_id, array($additional_option_term_exists['term_id']), 'additional_option', true );
			}
		}


	}

	// Localize script for the javascript
	function csv_import_table_script(){
		wp_register_script( 'script_csv1', plugin_dir_url( __FILE__ ) . 'js/script.js' );
		$this->localize_scripts();
	}

	// add admin menu
	function register_admin_menu_csv(){
		add_menu_page( 'CSV Import  Table', 'CSV Product Import', 'manage_options', 'import_csv_table', array( $this , 'csv_settings' ), '' , 80 );
		add_submenu_page( 'import_csv_table', 'Color Import', 'Color Import', 'manage_options', 'color_import', array( $this, 'color_csv_import' ) );
	}

	// Localize script for the javascript
	function localize_scripts(){

		$translation_array = array(
			'admin_ajax' => admin_url( 'admin-ajax.php' ),
			);
		wp_localize_script( 'script_csv1', 'translate', $translation_array );
		wp_enqueue_script( 'script_csv1' );

	}

	// Form for export and import
	function csv_settings(){
		?>
		<div class="wrap">
			<h2>CSV Product Import Table</h2>

			<form method="post" action="">
				<table class="form-table">
					<tr valign="top">
						<td>
							<input type="file" name="import_file" id="import_product_csv" />
							<button class="button" id="import_csvv" name="submit" type="button">Import</button>
							<img src="<?php echo includes_url( '/images/spinner.gif' ); ?>" class="spinner_loader" style="display:none;">
						</td>
					</tr>

				</table>

			</form>
		</div>

		<?php

	}

	function color_csv_import() {

		?>
		<div class="wrap">
			<h2>CSV Color Import Table</h2>

			<form method="post" action="">
				<table class="form-table">
					<tr valign="top">
						<td>
							<input type="file" name="import_color" id="import_color_csv" />
							<button class="button" id="color_import" name="submit" type="button">Import</button>
							<img src="<?php echo includes_url( '/images/spinner.gif' ); ?>" class="spinner_loader" style="display:none;">
						</td>
					</tr>

				</table>

			</form>
		</div>

		<?php

	}
}

$csv = new csv_import_table();